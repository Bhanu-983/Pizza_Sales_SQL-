-- Determine the distribution of orders by hour of the day.

SELECT 
    HOUR(orders.order_time) AS time,
    COUNT(order_details.order_id) AS Count
FROM
    orders
        JOIN
    order_details ON order_details.order_id = orders.order_id
GROUP BY time;